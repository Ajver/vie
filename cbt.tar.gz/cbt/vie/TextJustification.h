#pragma once

namespace vie
{

	enum class TextJustification
	{
		LEFT, CENTER, RIGHT
	};

}