#ifndef MAINCLASS_H
#define MAINCLASS_H

#include "../vie/Engine.h"
#include "../vie/Timer.h"

#include <vector>

class MainClass : public vie::Engine
{
public:
    MainClass();
    ~MainClass();

    void onCreate();

    void update(float et);
    void render(vie::Graphics* g);

private:
    vie::Timer timer;
    std::vector<glm::vec2> points;

};

#endif // MAINCLASS_H
