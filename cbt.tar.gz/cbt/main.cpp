#include <iostream>
#include <SDL2/SDL.h>

#include "MainClass.h"

using namespace std;

int main(int argc, char* argv[])
{
    MainClass();

    return 0;
}
