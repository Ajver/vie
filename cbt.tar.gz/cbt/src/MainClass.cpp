#include "MainClass.h"

MainClass::MainClass()
{
    runEngine();
}

MainClass::~MainClass() {}

void MainClass::onCreate() {}

void MainClass::update(float et) {}

void MainClass::render(vie::Graphics* g)
{
    g->setBackgroundColor(vie::COLOR::BLUE);
}
