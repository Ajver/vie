#include "MainClass.h"

#include "../vie/Window.h"

#include <iostream>

MainClass::MainClass()
{
    runEngine("Test VIE", 700, 700);
}

MainClass::~MainClass() {}

void MainClass::onCreate()
{
    mainCamera->setPosition(vie::Window::getScreenSize() * 0.5f);
    timer.start(5000);

    std::cout << "Screen size:" << std::endl;
    std::cout << vie::Window::getScreenWidth() << " x " << vie::Window::getScreenHeight() << std::endl;
}

void MainClass::update(float et) {}

void MainClass::render(vie::Graphics* g)
{
    g->setBackgroundColor(vie::COLOR::BLUE);
	g->setColor(vie::COLOR::YELLOW);

	static const glm::vec2 FROM = { 32, vie::Window::getScreenHeight() - 32 };
	static const glm::vec2 TO   = { vie::Window::getScreenWidth() - 32, 32 };
    static const glm::vec2 SIZE = { 32, 32 };

    glm::vec2 pos;
    pos.x = timer.getProgress();
    pos.y = timer.getDecreasingProgress();

    pos.x = pos.x * (TO.x-FROM.x) + FROM.x;
    pos.y = pos.y * (TO.y-FROM.y) + FROM.y;

    if(!timer.tick())
    {
        //std::cout << "P[" << points.size() << "]: (" << pos.x << "; " << pos.y << ")" << std::endl;
        points.push_back(pos);
    }

    g->setColor(vie::COLOR::WHITE);

    g->drawLine({FROM.x, vie::Window::getScreenHeight()}, {FROM.x, 0});
    g->drawLine({vie::Window::getScreenWidth(), FROM.y}, {0, FROM.y});

    g->setColor(vie::COLOR::YELLOW * vie::Color(255, 255, 255, 128));

    g->drawLine({TO.x, vie::Window::getScreenHeight()}, {TO.x, 0});
    g->drawLine({vie::Window::getScreenWidth(), TO.y}, {0, TO.y});

    g->setColor(vie::Color(255, 255, 255, 64));

    for(float i=0.1f; i<1; i+=0.1f)
    {
        glm::vec2 offset = (TO - FROM) * i;

        g->drawLine({FROM.x + offset.x, vie::Window::getScreenHeight()}, {FROM.x + offset.x, 0});
        g->drawLine({vie::Window::getScreenWidth(), FROM.y + offset.y}, {0, FROM.y + offset.y});
    }

    g->setColor(vie::COLOR::ORANGE);
    for(int i=1; i<points.size(); i++)
        g->drawLine(points[i-1], points[i]);

    g->setColor(vie::COLOR::GREEN);
    g->fillOval(pos, SIZE * 0.5f);
}
